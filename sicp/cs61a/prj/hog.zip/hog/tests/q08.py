test = {
  'names': [
    'q08',
    '8',
    'q8'
  ],
  'points': 1,
  'suites': [
    [
      {
        'locked': True,
        'test': """
        >>> bacon_strategy(0, 0)
        23e1b9da9cf4a7d1fa29ae26512645ef
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> bacon_strategy(70, 50)
        23e1b9da9cf4a7d1fa29ae26512645ef
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> bacon_strategy(50, 70)
        aa5583c8c6d4fd34018f09900374ac68
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> bacon_strategy(32, 4, 5, 4)
        aa5583c8c6d4fd34018f09900374ac68
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> bacon_strategy(20, 25, 5, 4)
        b1dfe57e56297284419307592a8af908
        # locked
        """,
        'type': 'doctest'
      }
    ]
  ]
}