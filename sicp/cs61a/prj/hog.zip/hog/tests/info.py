info = {
  'name': 'cal/61A/fa14/proj1',
  'params': {
    'doctest': {
      'cache': """
      import hog
      from hog import *
      """
    }
  },
  'src_files': [
    'hog.py'
  ],
  'version': '1.0'
}