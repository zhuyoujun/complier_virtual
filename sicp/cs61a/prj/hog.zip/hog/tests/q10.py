test = {
  'names': [
    'q10',
    '10'
  ],
  'note': """
  Tests for Q10 are not included with ok.
  Submit your project to receive results by email.
  """,
  'params': {
    'doctest': {
      'setup': "print('True average win rate of final_strategy is', win_rate)"
    }
  },
  'points': 3,
  'suites': [
    [
    
    ],
    [
    
    ],
    [
    
    ]
  ]
}